/*
 * Elephant_test.cpp
 *
 *  Created on: Oct 5, 2017
 *      Author: two
 */

#include "Elephant.h"


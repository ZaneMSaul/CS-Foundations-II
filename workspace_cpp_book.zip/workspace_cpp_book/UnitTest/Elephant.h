/*
 * Elephant.h
 *
 *  Created on: Oct 5, 2017
 *      Author: two
 */

#ifndef ELEPHANT_H_
#define ELEPHANT_H_

class Elephant {
public:
	Elephant();
	virtual ~Elephant();
};

#endif /* ELEPHANT_H_ */

/*
 * Elephant.cpp
 *
 *  Created on: Oct 5, 2017
 *      Author: two
 */

#include "Elephant.h"

Elephant::Elephant() {
	// TODO Auto-generated constructor stub

}

Elephant::~Elephant() {
	// TODO Auto-generated destructor stub
}


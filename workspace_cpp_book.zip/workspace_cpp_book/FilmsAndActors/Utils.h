/*
 * Utils.h
 *
 *  Created on: Oct 21, 2017
 *      Author: two
 */

#ifndef UTILS_H_
#define UTILS_H_

#include <string>

class Utils {
private:
	Utils();

public:
	static int stringToInt(std::string aString) ;

};

#endif /* UTILS_H_ */

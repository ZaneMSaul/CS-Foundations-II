//
//  SavingsAccount.cpp
//  Assignment7
//
//  Created by zane saul on 11/8/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#include "SavingsAccount.hpp"
#include <iostream>
#include <iomanip>
#include <sstream>

SavingsAccount::SavingsAccount( double beginningBalance ){
    int balance,
    numberOfDeposits,
    numberOfWithdrawals;

}
double SavingsAccount::deposit( double amount ){
    if( amount <= 0 ) {
        std::cout << "***ERROR: invalid deposit amount " << amount << std::endl;
        return 0;
    }
    numberOfDeposits++;
    balance = balance + convertToCents( amount );

}
double SavingsAccount::withdraw( ){
    active = status();
    if( active == false ){
        std::cout << "***Error: Account Inactive " << active
                  << std::endl;
        return 0;
    }
    if( amount <= 0 ){
        std::cout << "***ERROR: invalid deposit amount "
        << amount << std::endl;
        return 0;
    }
    int amountInCents = convertToCents( amount );
    if ( ( balance - amountInCents ) <= 0){
        std::cout << "***ERROR: overdraw request or withdraw would zero our account "
        << amount << std::endl;
        return 0;
    }
    balance = balance - amountInCents;
    numberOfWithdrawals++;
    return amount;
}
double SavingsAccount::ProcessMonthEnd( ){
    calculateInterest( );
    calculateServiceCharge( );
    setNumberOfDeposits( 0 );
    setNumberOfWithdrawals( 0 );
}
void SavingsAccount::printMonthlyStatement( ){
    
}
bool SavingsAccount::status( ){
    
}

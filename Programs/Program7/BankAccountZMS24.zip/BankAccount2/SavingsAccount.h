//
//  SavingsAccount.hpp
//  Assignment7
//
//  Created by zane saul on 11/8/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#ifndef SavingsAccount_h
#define SavingsAccount_h

#include <stdio.h>
#include <vector>
#include "BankAccount.h"

class SavingsAccount: public BankAccount {
private:
    const int WITHDRAWAL_SERVICE_CHARGE = 1;
    bool active;

    double DepositAmount,
           WithdrawalAmount;

    virtual void printMonthlyStatement( );
    void calculateServiceCharge( );
    bool status( );

public:
    SavingsAccount( double );
    virtual void deposit( double );
    virtual double withdraw( double );
    virtual void processMonthEnd( );
};

#endif /* SavingsAccount_h */

//
//  Stack.cpp
//  Assignment 8
//
//  Created by zane saul on 12/9/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#include "Stack.hpp"
#include "LinkedList.hpp"

Stack::Stack(){
    
}
void Stack::push( int ){

}
int Stack::pop(){
    
}
int Stack::peek(){
    
}
bool Stack::empty(){
    
}
Stack::~Stack(){
    
}


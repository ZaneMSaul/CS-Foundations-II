//
//  Stack.hpp
//  Assignment 8
//
//  Created by zane saul on 12/9/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#ifndef Stack_hpp
#define Stack_hpp

#include <stdio.h>
#include "LinkedList.hpp"

class Stack
{
private:
    LInkedList stack;
public:
    Stack();
    void push( int );
    int pop();
    int peek();
    bool empty();
    virtual ~Stack();
};

#endif /* Stack_hpp */

//
//  Queue.hpp
//  Assignment 8
//
//  Created by zane saul on 12/9/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#ifndef Queue_hpp
#define Queue_hpp

#include <stdio.h>
#include "LinkedList.hpp"

class queue
{
private:
    LinkedList Queue;
    queue *rear;
    queue *front;
public:
    queue();
    void enqueue();
    int dequeue();
    bool isEmpty();
    void clear();
    virtual~queue();
};

#endif /* Queue_hpp */

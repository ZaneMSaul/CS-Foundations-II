//
//  Queue.cpp
//  Assignment 8
//
//  Created by zane saul on 12/9/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#include "Queue.hpp"

queue::queue(){
    
}
void queue::enqueue(){
    
}
int queue::dequeue(){
    
}
bool queue::isEmpty(){
    
}
void queue::clear(){
    
}
queue::~queue(){
}


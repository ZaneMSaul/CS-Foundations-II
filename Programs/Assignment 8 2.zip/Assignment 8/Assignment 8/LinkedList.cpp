//
//  LinkedList.cpp
//  Assignment 8
//
//  Created by zane saul on 12/9/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#include "LinkedList.hpp"
#include "IntegerListNode.hpp"
#include <iostream>

ListNode *head;
ListNode *tail;

LinkedList::LinkedList(){
    head = nullptr;
    tail = nullptr;
}

ListNode *getFirst(){
    
}
ListNode *getLast(){
    
}
 //goes to bottom of stack
void LinkedList::append( ListNode * node ){
    if( head == nullptr ){
        head = node;
        tail = node;
        return;
    }else{
        node = next
    }
    
    //work
}
//goes to top of stack
void LinkedList::prepend( ListNode * newnode){
    if( !head ){
        head = newnode;
        newnode->setNext(nullptr);
    }else{
        newnode=head;
        head=newnode;}
}
void LinkedList::traverse (){
    ListNode *tempnode = head;
    while(tempnode -> getNext() != 0 ){
        tempnode = tempnode->getNext();
        std::cout << dynamic_cast<IntegerListNode*>(tempnode)->getNext() << std::endl;
    }
}
bool LinkedList::isempty(){
    if( head == nullptr )
        return true;
    else
        return false;
}
LinkedList::~LinkedList(){
}

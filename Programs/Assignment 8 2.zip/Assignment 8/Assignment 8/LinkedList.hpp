//
//  LinkedList.hpp
//  Assignment 8
//
//  Created by zane saul on 12/9/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#ifndef LinkedList_hpp
#define LinkedList_hpp

#include <stdio.h>
#include "ListNode.hpp"

class LinkedList
{
public:
    LinkedList();
    ListNode *getFirst();
    ListNode *getLast();
    bool isempty();
    void append( ListNode * );
    void prepend( ListNode * );
    void traverse ();
    virtual ~LinkedList();
};

#endif /* LinkedList_hpp */

//
//  Utils.h
//  Program6
//
//  Created by zane saul on 10/27/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#ifndef Utils_h
#define Utils_h

class Utils{
private:
    Utils();
public:
    static int stringToInt( std::string aString );
};

#endif /* Utils_h */

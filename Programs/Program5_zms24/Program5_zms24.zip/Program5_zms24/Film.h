//
//  Film.h
//  Program5_zms24
//
//  Created by zane saul on 10/12/17.
//  Copyright © 2017 zane saul. All rights reserved.
//

#ifndef Film_h
#define Film_h

#include <string>

int size = 4;

enum FilmRating  {G, PG, PG_13, NC_17, R, UNRATED};

class Film
{
private:
    int id;               // the unique id of the film
    
    std::string name;          // the film's name
    
    std::string description;   // the film's description
    
    int runningTime;      // the film's running time in minutes <= 180
    
    std::string rating;    // the film's rating, from the enum FilmRating
    
public:
    Film(int aid, std::string aname, std::string adescription,
         int arunningTime,  int arating);
    Film ( int , std::string , std::string , int, std::string );
    Film ( int id, std::string, std::string, int, FilmRating );
    void getFilms( int, std::vector<Film> temporary );
    int getId( )
    {
        return id;
    }
    std::string getName( )
    {
        return name;
    }
    std::string getDescription( )
    {
        return description;
    }
    int getRunningTime( )
    {
        return runningTime;
    }
    FilmRating getRating( )
    {
        return rating;
    }
    void printFilm( );
    std::string filmRatingToString( FilmRating rating );

};

#endif /* Film_h */

#include "Film.h"
#include <iostream>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <iomanip>

Film :: Film(int aid, std::string aname, std::string adescription,
             int arunningTime,  int arating)
{
    id = 0;
    name = "";
    description = "";
    runningTime = 0;
    rating = UNRATED;
}

/*
 This constructor should assign the parameters to the appropriate attributes of
 the class.
 Note: you will need to convert the rating parameter to a FilmRating type.
 */

Film :: Film(int aid, std::string aname, std::string adescription,
             int arunningTime,  std::string arating)
{
    id = aid;
    name = aname;
    description = adescription;
    runningTime = arunningTime;
    rating = filmRatingToString( arating );
}

/*
 This constructor should assign the parameters to the appropriate attributes of
 the class. Include a method print that will print the attributes of Film
 nicely. This should include the FilmRating attribute     as a string;
 */

Film :: Film(int aid, std::string aname, std::string adescription,
             int arunningTime, FilmRating arating)
{
    id = aid;
    name = aname;
    description = adescription;
    runningTime = arunningTime;
    rating = filmRatingToString( arating );
}
void Film::getFilms( int i, std::vector<Film> temporary )
{
    temporary[i].id = id;
    temporary[i].name = name;
    temporary[i].description = description;
    temporary[i].runningTime = runningTime;
    temporary[i].rating = rating;
}

/*
 Function: filmRatingToString
 
 The function, filmRatingToString, Returns a readable version of the
 rating constant, e.g., with an input of G returns the string “G”
 
 Receives: FilmRating rating
 Constants: enum FilmRating
 Returns: result
 */

std::string filmRatingToString( FilmRating rating )
{
    std::string result;
    
    if( rating == 0 )
        result = "G";
    else if( rating == 1 )
        result = "PG";
    else if( rating == 2 )
        result = "PG_13";
    else if( rating == 3 )
        result = "NC_17";
    else if( rating == 4 )
        result = "R";
    else if( rating == 5 )
        result = "Unrated";
    
    return result;
}

/*
 Function: printResults
 
 The function, printResults, is called print all the values in the vector
 films. It will print the title, discription, run time, and rating
 respectively.
 
 Film title          : Bambi
 Film description    : A young deer grows up
 Film running time   : 70 minutes
 Film rating         : G
 
 Recieves: Film *films, int newSize
 Constants: None
 Returns: Nothing, prints to screen.
 */

void Film::printFilm( )
{
    std::cout << "Film title" << std::right << std::setw(10) << ": " << name
              << std::endl
              << "Film description" << std::right << std::setw(4) << ": "
              << description << std::endl
              << "Film running time" << std::right << std::setw(3) << ": "
              << runningTime << " mins" << std::endl
              << "Film rating" << std::right << std::setw(9) << ": " << rating
              << std::endl
              << std::endl;
}
/*
 Function: printFilm
 
 The function, printFilm, Prints the struct film to the console in a readable
 format,
 
 Receives: Film film
 Constants: None
 Returns: Nothing, Prints to screen


void printFilm( Film films )
{
    std::string name = films.getName( );
    std::string description = films.getDescription( );
    int runningTime = films.getRunningTime( );
    FilmRating rating = films.getRating( );
    
    std::cout << "Film title" << std::right << std::setw(10) << ": " << name
              << std::endl
              << "Film description" << std::right << std::setw(4) << ": "
              << description << std::endl
              << "Film running time" << std::right << std::setw(3) << ": "
              << runningTime << " mins" << std::endl
              << "Film rating" << std::right << std::setw(9) << ": " << rating
              << std::endl
    << std::endl;
}
 */
